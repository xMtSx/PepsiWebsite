
export const Content = () => {
      return(  
      <div className="content">
            <h1>Lorem ipsum dolor sit amet consectetur adipisicing elit.</h1>
            <button>Kup teraz</button>
        </div>
      );
}