import { Wrapper } from "./Wrapper";
function App() {
  return <Wrapper/>
}

export default App;
